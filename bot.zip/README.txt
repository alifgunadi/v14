https://discord.com/developers/applications/978476535373770794/bot;
https://discord.com/developers/applications/978476535373770794/oauth2/url-generator;
check the 'bot' and applications.commands;
go to administrator;
Token Discord : ??;
npm install discord.js discord-api-types @discordjs/rest dotenv chalk@4.1.2;

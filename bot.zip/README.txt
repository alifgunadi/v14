https://discord.com/developers/applications
check the 'bot' and applications.commands;
go to administrator;
Token Discord : ??;
npm install discord.js discord-api-types @discordjs/rest dotenv chalk@4.1.2;
